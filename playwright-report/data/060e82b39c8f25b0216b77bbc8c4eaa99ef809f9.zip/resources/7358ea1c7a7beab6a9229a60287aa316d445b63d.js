import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MidnightCheckout/MidnightCheckout.tsx");const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Midnight Checkout Component
* The haunted apothecary checkout interface with four intentional defects
* Requirements: 2.1, 2.3, 4.1, 5.1, 6.1, 7.1
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=ef000833";
import styles from "/src/components/MidnightCheckout/MidnightCheckout.module.css";
var _jsxFileName = "D:/personal-project/hackathons/kiroween-141126/keyquest/src/components/MidnightCheckout/MidnightCheckout.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ef000833";
var _s = $RefreshSig$();
export function MidnightCheckout({ onDefectInteraction }) {
	_s();
	const [quantity, setQuantity] = useState(1);
	const [addedToCart, setAddedToCart] = useState(false);
	const handleAddToCart = useCallback(() => {
		setAddedToCart(true);
		// Reset after a moment for demo purposes
		setTimeout(() => setAddedToCart(false), 2e3);
	}, []);
	const handleDefectFocus = useCallback(() => {
		onDefectInteraction?.("mouse-only-activation");
	}, [onDefectInteraction]);
	const subtotal = (quantity * 13.99).toFixed(2);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.checkout,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.storeHeader,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.storeBrand,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: styles.apothecaryTag,
						children: "NOCTURNE APOTHECARY · EST. 1899"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: styles.shopTitle,
						children: "The Midnight Checkout"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: styles.cartIcon,
					"data-testid": "defect-missing-name",
					type: "button",
					children: /* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": "true",
						children: "🛒"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.product,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.productImage,
					"aria-hidden": "true",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						viewBox: "0 0 120 120",
						width: "96",
						height: "96",
						className: styles.candleSvg,
						"aria-hidden": "true",
						focusable: "false",
						children: [
							/* @__PURE__ */ _jsxDEV("circle", {
								cx: "60",
								cy: "32",
								r: "22",
								fill: "#fbbf24",
								fillOpacity: "0.14",
								className: styles.flameHalo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M60 12C60 12 71 25 69 35C67.5 42.5 63.5 46 60 46C56.5 46 52.5 42.5 51 35C49 25 60 12 60 12Z",
								fill: "#fbbf24",
								className: styles.flameOuter
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M60 22C60 22 65 30 64 36C63.2 40 61.5 42 60 42C58.5 42 56.8 40 56 36C55 30 60 22 60 22Z",
								fill: "#fffbeb"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("line", {
								x1: "60",
								y1: "45",
								x2: "60",
								y2: "50",
								stroke: "#eaeaea",
								strokeWidth: "2",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("rect", {
								x: "44",
								y: "50",
								width: "32",
								height: "44",
								rx: "4",
								fill: "#261c3a",
								stroke: "#a78bfa",
								strokeWidth: "1.5"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M44 54Q50 62 52 54T60 58T69 53T76 56",
								fill: "none",
								stroke: "#c4b5fd",
								strokeWidth: "2",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M50 54V66M66 54V62",
								stroke: "#c4b5fd",
								strokeWidth: "2.5",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M34 94H86L80 102H40L34 94Z",
								fill: "#b45309",
								stroke: "#fbbf24",
								strokeWidth: "1.5",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M82 94C89 94 92 88 89 83C86 79 81 82 81 86",
								fill: "none",
								stroke: "#fbbf24",
								strokeWidth: "2",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.productInfo,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: styles.productBadgeRow,
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: styles.artifactBadge,
								children: "ARCANE ARTIFACT #04"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: styles.stockBadge,
								children: "In Stock"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h4", {
							className: styles.productName,
							children: "Enchanted Candle"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: styles.productDescription,
							children: "A mysterious candle that never burns out. Perfect for midnight coding sessions and banishing shadowy UI bugs."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: styles.priceRow,
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: styles.priceLabel,
								children: "Unit Price:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: styles.productPrice,
								"data-testid": "defect-low-contrast",
								children: "$13.99"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.controls,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.quantityControl,
					children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "quantity",
						className: styles.quantityLabel,
						children: "Quantity:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						id: "quantity",
						min: 1,
						max: 10,
						value: quantity,
						onChange: (e) => {
							const parsed = Number(e.target.value);
							setQuantity(Number.isNaN(parsed) ? 1 : Math.max(1, Math.min(10, parsed)));
						},
						className: styles.quantityInput
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.addButton,
					tabIndex: 0,
					onClick: handleAddToCart,
					onFocus: handleDefectFocus,
					"data-testid": "defect-mouse-only",
					"aria-label": "Add to cart",
					children: addedToCart ? "✓ Added!" : "Add to Cart"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.orderLedger,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.ledgerRow,
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Midnight Courier Delivery" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: styles.ledgerFree,
						children: "FREE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.ledgerRowTotal,
					children: [/* @__PURE__ */ _jsxDEV("span", { children: [
						"Order Total (",
						quantity,
						" ",
						quantity === 1 ? "item" : "items",
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["$", subtotal] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: styles.buyButton,
				"data-testid": "defect-invisible-focus",
				type: "button",
				children: "Buy Now"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 223,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 5
	}, this);
}
_s(MidnightCheckout, "uN58OgooRU3e5kUUk0MYNPY+NJM=");
_c = MidnightCheckout;
var _c;
$RefreshReg$(_c, "MidnightCheckout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MidnightCheckout/MidnightCheckout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/personal-project/hackathons/kiroween-141126/keyquest/src/components/MidnightCheckout/MidnightCheckout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/personal-project/hackathons/kiroween-141126/keyquest/src/components/MidnightCheckout/MidnightCheckout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/personal-project/hackathons/kiroween-141126/keyquest/src/components/MidnightCheckout/MidnightCheckout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxTQUFTLFVBQVUsbUJBQW1CO0FBQ3RDLE9BQU8sWUFBWTs7OztBQU1uQixPQUFPLFNBQVMsaUJBQWlCLEVBQy9CLHVCQUN3Qjs7Q0FDeEIsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FDMUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUVwRCxNQUFNLGtCQUFrQixrQkFBa0I7RUFDeEMsZUFBZSxJQUFJOztFQUVuQixpQkFBaUIsZUFBZSxLQUFLLEdBQUcsR0FBSTtDQUM5QyxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sb0JBQW9CLGtCQUFrQjtFQUMxQyxzQkFBc0IsdUJBQXVCO0NBQy9DLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztDQUV4QixNQUFNLFlBQVksV0FBVyxNQUFLLENBQUUsUUFBUSxDQUFDO0NBRTdDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsT0FBTztZQUF2QjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLE9BQU87Y0FBdkIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVcsT0FBTztnQkFBZTtLQUVqQzs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBSSxXQUFXLE9BQU87Z0JBQVc7S0FBeUI7Ozs7YUFDdkQ7Ozs7O2NBTUwsd0JBQUMsVUFBRDtLQUNFLFdBQVcsT0FBTztLQUNsQixlQUFZO0tBQ1osTUFBSztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxlQUFZO2dCQUFPO0tBQVE7Ozs7O0lBQzNCOzs7O1lBQ0w7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLE9BQU87Y0FBdkIsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO0tBQWMsZUFBWTtlQUMvQyx3QkFBQyxPQUFEO01BQ0UsU0FBUTtNQUNSLE9BQU07TUFDTixRQUFPO01BQ1AsV0FBVyxPQUFPO01BQ2xCLGVBQVk7TUFDWixXQUFVO2dCQU5aO09BU0Usd0JBQUMsVUFBRDtRQUNFLElBQUc7UUFDSCxJQUFHO1FBQ0gsR0FBRTtRQUNGLE1BQUs7UUFDTCxhQUFZO1FBQ1osV0FBVyxPQUFPO09BQ25COzs7OztPQUVELHdCQUFDLFFBQUQ7UUFDRSxHQUFFO1FBQ0YsTUFBSztRQUNMLFdBQVcsT0FBTztPQUNuQjs7Ozs7T0FFRCx3QkFBQyxRQUFEO1FBQ0UsR0FBRTtRQUNGLE1BQUs7T0FDTjs7Ozs7T0FFRCx3QkFBQyxRQUFEO1FBQ0UsSUFBRztRQUNILElBQUc7UUFDSCxJQUFHO1FBQ0gsSUFBRztRQUNILFFBQU87UUFDUCxhQUFZO1FBQ1osZUFBYztPQUNmOzs7OztPQUVELHdCQUFDLFFBQUQ7UUFDRSxHQUFFO1FBQ0YsR0FBRTtRQUNGLE9BQU07UUFDTixRQUFPO1FBQ1AsSUFBRztRQUNILE1BQUs7UUFDTCxRQUFPO1FBQ1AsYUFBWTtPQUNiOzs7OztPQUVELHdCQUFDLFFBQUQ7UUFDRSxHQUFFO1FBQ0YsTUFBSztRQUNMLFFBQU87UUFDUCxhQUFZO1FBQ1osZUFBYztPQUNmOzs7OztPQUNELHdCQUFDLFFBQUQ7UUFDRSxHQUFFO1FBQ0YsUUFBTztRQUNQLGFBQVk7UUFDWixlQUFjO09BQ2Y7Ozs7O09BRUQsd0JBQUMsUUFBRDtRQUNFLEdBQUU7UUFDRixNQUFLO1FBQ0wsUUFBTztRQUNQLGFBQVk7UUFDWixnQkFBZTtPQUNoQjs7Ozs7T0FDRCx3QkFBQyxRQUFEO1FBQ0UsR0FBRTtRQUNGLE1BQUs7UUFDTCxRQUFPO1FBQ1AsYUFBWTtRQUNaLGVBQWM7T0FDZjs7Ozs7TUFDRTs7Ozs7O0lBQ0Y7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVcsT0FBTztpQkFBdkIsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVyxPQUFPO2tCQUFlO09BQXlCOzs7O2lCQUNoRSx3QkFBQyxRQUFEO1FBQU0sV0FBVyxPQUFPO2tCQUFZO09BQWM7Ozs7ZUFDL0M7Ozs7OztNQUVMLHdCQUFDLE1BQUQ7T0FBSSxXQUFXLE9BQU87aUJBQWE7TUFBb0I7Ozs7O01BQ3ZELHdCQUFDLEtBQUQ7T0FBRyxXQUFXLE9BQU87aUJBQW9CO01BR3RDOzs7OztNQUVILHdCQUFDLE9BQUQ7T0FBSyxXQUFXLE9BQU87aUJBQXZCLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVcsT0FBTztrQkFBWTtPQUFpQjs7OztpQkFLckQsd0JBQUMsS0FBRDtRQUNFLFdBQVcsT0FBTztRQUNsQixlQUFZO2tCQUNiO09BRUU7Ozs7ZUFDQTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLE9BQU87Y0FBdkIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7TUFBVyxXQUFXLE9BQU87Z0JBQWU7S0FFcEQ7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLElBQUc7TUFDSCxLQUFLO01BQ0wsS0FBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU07T0FDZixNQUFNLFNBQVMsT0FBTyxFQUFFLE9BQU8sS0FBSztPQUNwQyxZQUFZLE9BQU8sTUFBTSxNQUFNLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQztNQUMxRTtNQUNBLFdBQVcsT0FBTztLQUNuQjs7OzthQUNFOzs7OztjQU9MLHdCQUFDLE9BQUQ7S0FDRSxXQUFXLE9BQU87S0FDbEIsVUFBVTtLQUNWLFNBQVM7S0FDVCxTQUFTO0tBQ1QsZUFBWTtLQUNaLGNBQVc7ZUFFVixjQUFjLGFBQWE7SUFDekI7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUF2QixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLE9BQU87ZUFBdkIsQ0FDRSx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O2VBQ3JDLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLE9BQU87Z0JBQVk7S0FBVTs7OzthQUMzQzs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCLENBQ0Usd0JBQUMsUUFBRDtNQUFNO01BQWM7TUFBUztNQUFFLGFBQWEsSUFBSSxTQUFTO01BQVE7S0FBTzs7OztlQUN4RSx3QkFBQyxRQUFELGFBQU0sS0FBRSxRQUFlOzs7O2FBQ3BCOzs7OztZQUNGOzs7Ozs7R0FNTCx3QkFBQyxVQUFEO0lBQ0UsV0FBVyxPQUFPO0lBQ2xCLGVBQVk7SUFDWixNQUFLO2NBQ047R0FFTzs7Ozs7RUFDTDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWlkbmlnaHRDaGVja291dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBNaWRuaWdodCBDaGVja291dCBDb21wb25lbnRcbiAqIFRoZSBoYXVudGVkIGFwb3RoZWNhcnkgY2hlY2tvdXQgaW50ZXJmYWNlIHdpdGggZm91ciBpbnRlbnRpb25hbCBkZWZlY3RzXG4gKiBSZXF1aXJlbWVudHM6IDIuMSwgMi4zLCA0LjEsIDUuMSwgNi4xLCA3LjFcbiAqL1xuXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vTWlkbmlnaHRDaGVja291dC5tb2R1bGUuY3NzJztcblxuaW50ZXJmYWNlIE1pZG5pZ2h0Q2hlY2tvdXRQcm9wcyB7XG4gIG9uRGVmZWN0SW50ZXJhY3Rpb24/OiAoZGVmZWN0VHlwZTogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gTWlkbmlnaHRDaGVja291dCh7XG4gIG9uRGVmZWN0SW50ZXJhY3Rpb24sXG59OiBNaWRuaWdodENoZWNrb3V0UHJvcHMpIHtcbiAgY29uc3QgW3F1YW50aXR5LCBzZXRRdWFudGl0eV0gPSB1c2VTdGF0ZSgxKTtcbiAgY29uc3QgW2FkZGVkVG9DYXJ0LCBzZXRBZGRlZFRvQ2FydF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgaGFuZGxlQWRkVG9DYXJ0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldEFkZGVkVG9DYXJ0KHRydWUpO1xuICAgIC8vIFJlc2V0IGFmdGVyIGEgbW9tZW50IGZvciBkZW1vIHB1cnBvc2VzXG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRBZGRlZFRvQ2FydChmYWxzZSksIDIwMDApO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlRGVmZWN0Rm9jdXMgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgb25EZWZlY3RJbnRlcmFjdGlvbj8uKCdtb3VzZS1vbmx5LWFjdGl2YXRpb24nKTtcbiAgfSwgW29uRGVmZWN0SW50ZXJhY3Rpb25dKTtcblxuICBjb25zdCBzdWJ0b3RhbCA9IChxdWFudGl0eSAqIDEzLjk5KS50b0ZpeGVkKDIpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jaGVja291dH0+XG4gICAgICB7LyogU3RvcmVmcm9udCBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnN0b3JlSGVhZGVyfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5zdG9yZUJyYW5kfT5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy5hcG90aGVjYXJ5VGFnfT5cbiAgICAgICAgICAgIE5PQ1RVUk5FIEFQT1RIRUNBUlkgwrcgRVNULiAxODk5XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9e3N0eWxlcy5zaG9wVGl0bGV9PlRoZSBNaWRuaWdodCBDaGVja291dDwvaDM+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBERUZFQ1QgMzogTWlzc2luZyBBY2Nlc3NpYmxlIE5hbWVcbiAgICAgICAgICogSWNvbi1vbmx5IGJ1dHRvbiB3aXRoIG5vIGFyaWEtbGFiZWwsIHRleHQsIG9yIHRpdGxlLlxuICAgICAgICAgKiBWaW9sYXRlcyBXQ0FHIDQuMS4yIChOYW1lLCBSb2xlLCBWYWx1ZSkuXG4gICAgICAgICAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmNhcnRJY29ufVxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZGVmZWN0LW1pc3NpbmctbmFtZVwiXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7wn5uSPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRmVhdHVyZWQgQXJ0aWZhY3QgQ2FyZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucHJvZHVjdH0+XG4gICAgICAgIHsvKiBCZXNwb2tlIEVuY2hhbnRlZCBDYW5kbGUgU1ZHIElsbHVzdHJhdGlvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0SW1hZ2V9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMTIwIDEyMFwiXG4gICAgICAgICAgICB3aWR0aD1cIjk2XCJcbiAgICAgICAgICAgIGhlaWdodD1cIjk2XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmNhbmRsZVN2Z31cbiAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgICBmb2N1c2FibGU9XCJmYWxzZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgey8qIEFtYmllbnQgaGFsbyAqL31cbiAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgY3g9XCI2MFwiXG4gICAgICAgICAgICAgIGN5PVwiMzJcIlxuICAgICAgICAgICAgICByPVwiMjJcIlxuICAgICAgICAgICAgICBmaWxsPVwiI2ZiYmYyNFwiXG4gICAgICAgICAgICAgIGZpbGxPcGFjaXR5PVwiMC4xNFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmZsYW1lSGFsb31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7LyogT3V0ZXIgZmxhbWUgKi99XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBkPVwiTTYwIDEyQzYwIDEyIDcxIDI1IDY5IDM1QzY3LjUgNDIuNSA2My41IDQ2IDYwIDQ2QzU2LjUgNDYgNTIuNSA0Mi41IDUxIDM1QzQ5IDI1IDYwIDEyIDYwIDEyWlwiXG4gICAgICAgICAgICAgIGZpbGw9XCIjZmJiZjI0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuZmxhbWVPdXRlcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7LyogSW5uZXIgZmxhbWUgY29yZSAqL31cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGQ9XCJNNjAgMjJDNjAgMjIgNjUgMzAgNjQgMzZDNjMuMiA0MCA2MS41IDQyIDYwIDQyQzU4LjUgNDIgNTYuOCA0MCA1NiAzNkM1NSAzMCA2MCAyMiA2MCAyMlpcIlxuICAgICAgICAgICAgICBmaWxsPVwiI2ZmZmJlYlwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgey8qIFdpY2sgKi99XG4gICAgICAgICAgICA8bGluZVxuICAgICAgICAgICAgICB4MT1cIjYwXCJcbiAgICAgICAgICAgICAgeTE9XCI0NVwiXG4gICAgICAgICAgICAgIHgyPVwiNjBcIlxuICAgICAgICAgICAgICB5Mj1cIjUwXCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiI2VhZWFlYVwiXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgey8qIENhbmRsZSBib2R5ICovfVxuICAgICAgICAgICAgPHJlY3RcbiAgICAgICAgICAgICAgeD1cIjQ0XCJcbiAgICAgICAgICAgICAgeT1cIjUwXCJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMlwiXG4gICAgICAgICAgICAgIGhlaWdodD1cIjQ0XCJcbiAgICAgICAgICAgICAgcng9XCI0XCJcbiAgICAgICAgICAgICAgZmlsbD1cIiMyNjFjM2FcIlxuICAgICAgICAgICAgICBzdHJva2U9XCIjYTc4YmZhXCJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjVcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHsvKiBXYXggZHJpcHMgKi99XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBkPVwiTTQ0IDU0UTUwIDYyIDUyIDU0VDYwIDU4VDY5IDUzVDc2IDU2XCJcbiAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICBzdHJva2U9XCIjYzRiNWZkXCJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBkPVwiTTUwIDU0VjY2TTY2IDU0VjYyXCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiI2M0YjVmZFwiXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMi41XCJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7LyogQnJhc3MgaG9sZGVyIGJhc2UgKi99XG4gICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICBkPVwiTTM0IDk0SDg2TDgwIDEwMkg0MEwzNCA5NFpcIlxuICAgICAgICAgICAgICBmaWxsPVwiI2I0NTMwOVwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cIiNmYmJmMjRcIlxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGQ9XCJNODIgOTRDODkgOTQgOTIgODggODkgODNDODYgNzkgODEgODIgODEgODZcIlxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cIiNmYmJmMjRcIlxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByb2R1Y3QgSW5mbyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0SW5mb30+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0QmFkZ2VSb3d9PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMuYXJ0aWZhY3RCYWRnZX0+QVJDQU5FIEFSVElGQUNUICMwNDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3R5bGVzLnN0b2NrQmFkZ2V9PkluIFN0b2NrPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT17c3R5bGVzLnByb2R1Y3ROYW1lfT5FbmNoYW50ZWQgQ2FuZGxlPC9oND5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0RGVzY3JpcHRpb259PlxuICAgICAgICAgICAgQSBteXN0ZXJpb3VzIGNhbmRsZSB0aGF0IG5ldmVyIGJ1cm5zIG91dC4gUGVyZmVjdCBmb3IgbWlkbmlnaHRcbiAgICAgICAgICAgIGNvZGluZyBzZXNzaW9ucyBhbmQgYmFuaXNoaW5nIHNoYWRvd3kgVUkgYnVncy5cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnByaWNlUm93fT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3R5bGVzLnByaWNlTGFiZWx9PlVuaXQgUHJpY2U6PC9zcGFuPlxuICAgICAgICAgICAgey8qIERFRkVDVCA0OiBJbnN1ZmZpY2llbnQgQ29udHJhc3RcbiAgICAgICAgICAgICAqIENvbG9yICM1NTU1NTUgb24gIzE2MjEzZSBzdXJmYWNlIGhhcyB+Mi4wOToxIGNvbnRyYXN0IHJhdGlvLlxuICAgICAgICAgICAgICogRmFpbHMgV0NBRyAxLjQuMyAoQ29udHJhc3QgTWluaW11bSkuXG4gICAgICAgICAgICAgKi99XG4gICAgICAgICAgICA8cFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5wcm9kdWN0UHJpY2V9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZGVmZWN0LWxvdy1jb250cmFzdFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICQxMy45OVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ29udHJvbHM6IFF1YW50aXR5ICsgQWRkIHRvIENhcnQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRyb2xzfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5xdWFudGl0eUNvbnRyb2x9PlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicXVhbnRpdHlcIiBjbGFzc05hbWU9e3N0eWxlcy5xdWFudGl0eUxhYmVsfT5cbiAgICAgICAgICAgIFF1YW50aXR5OlxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgIGlkPVwicXVhbnRpdHlcIlxuICAgICAgICAgICAgbWluPXsxfVxuICAgICAgICAgICAgbWF4PXsxMH1cbiAgICAgICAgICAgIHZhbHVlPXtxdWFudGl0eX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBwYXJzZWQgPSBOdW1iZXIoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICBzZXRRdWFudGl0eShOdW1iZXIuaXNOYU4ocGFyc2VkKSA/IDEgOiBNYXRoLm1heCgxLCBNYXRoLm1pbigxMCwgcGFyc2VkKSkpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLnF1YW50aXR5SW5wdXR9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERFRkVDVCAyOiBNb3VzZS1Pbmx5IEFjdGl2YXRpb25cbiAgICAgICAgICogVGhpcyBkaXYgYWN0cyBsaWtlIGEgYnV0dG9uIGJ1dCBPTkxZIHJlc3BvbmRzIHRvIG1vdXNlIGNsaWNrcy5cbiAgICAgICAgICogSXQgaGFzIHRhYmluZGV4PVwiMFwiIHNvIGl0J3MgZm9jdXNhYmxlLCBidXQgbm8ga2V5Ym9hcmQgaGFuZGxlcnMgYW5kIG5vIHJvbGU9XCJidXR0b25cIi5cbiAgICAgICAgICogVmlvbGF0ZXMgV0NBRyAyLjEuMSAoS2V5Ym9hcmQpLlxuICAgICAgICAgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5hZGRCdXR0b259XG4gICAgICAgICAgdGFiSW5kZXg9ezB9XG4gICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkVG9DYXJ0fVxuICAgICAgICAgIG9uRm9jdXM9e2hhbmRsZURlZmVjdEZvY3VzfVxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZGVmZWN0LW1vdXNlLW9ubHlcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJBZGQgdG8gY2FydFwiXG4gICAgICAgID5cbiAgICAgICAgICB7YWRkZWRUb0NhcnQgPyAn4pyTIEFkZGVkIScgOiAnQWRkIHRvIENhcnQnfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogT3JkZXIgTGVkZ2VyIFN1bW1hcnkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm9yZGVyTGVkZ2VyfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5sZWRnZXJSb3d9PlxuICAgICAgICAgIDxzcGFuPk1pZG5pZ2h0IENvdXJpZXIgRGVsaXZlcnk8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMubGVkZ2VyRnJlZX0+RlJFRTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubGVkZ2VyUm93VG90YWx9PlxuICAgICAgICAgIDxzcGFuPk9yZGVyIFRvdGFsICh7cXVhbnRpdHl9IHtxdWFudGl0eSA9PT0gMSA/ICdpdGVtJyA6ICdpdGVtcyd9KTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj4ke3N1YnRvdGFsfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIERFRkVDVCAxOiBJbnZpc2libGUgRm9jdXNcbiAgICAgICAqIEZvY3VzIGluZGljYXRvciBpcyByZW1vdmVkIHZpYSBvdXRsaW5lOiBub25lIHdpdGggbm8gcmVwbGFjZW1lbnQuXG4gICAgICAgKiBWaW9sYXRlcyBXQ0FHIDIuNC43IChGb2N1cyBWaXNpYmxlKS5cbiAgICAgICAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuYnV5QnV0dG9ufVxuICAgICAgICBkYXRhLXRlc3RpZD1cImRlZmVjdC1pbnZpc2libGUtZm9jdXNcIlxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgID5cbiAgICAgICAgQnV5IE5vd1xuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=